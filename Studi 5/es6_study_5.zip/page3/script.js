// Hapus code dibawah

// Hapus code diatas

// Import constant dog
import dog from "./dogData.js";

dog.info();