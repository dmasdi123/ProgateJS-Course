const characters = ["Ninja Ken", "Baby Ben", "Guru Domba"];

console.log(characters);

// Tambahkan string "Birdie" ke array characters dengan method push
characters.push("Birdie");

// Print array characters
console.log(characters);
