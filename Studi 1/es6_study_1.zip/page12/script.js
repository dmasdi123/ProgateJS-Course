const level = 12;

// Tambahkan pernyataan if dengan kondisi: level > 10
if ( level > 10) {
  console.log("Level Anda lebih tinggi dari 10");
}
